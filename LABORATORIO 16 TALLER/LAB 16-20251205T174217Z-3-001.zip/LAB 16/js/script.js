// Vista previa de imagen
function mostrarImagen(event) {
    let imagen = document.getElementById('ver-imagen');
    imagen.src = URL.createObjectURL(event.target.files[0]);
    imagen.style.display = "block";
}

// Validacion del formulario
document.getElementById("registro-form").addEventListener("submit", function(event) {
    let nombre = document.getElementById("nombre").value.trim();
    let correo = document.getElementById("correo").value.trim();
    let clave = document.getElementById("clave").value.trim();
    let archivo = document.getElementById("imagen").files[0];

    // Validacion básica
    if (nombre === "" || correo === "" || clave === "") {
        alert("Por favor, complete todos los campos.");
        event.preventDefault();
        return;
    }

    // Validar imagen
    if (archivo && !archivo.type.match("image.*")) {
        alert("La imagen debe ser JPG o PNG.");
        event.preventDefault();
        return;
    }

    alert("Registro exitoso.");
});
