
// PARTE 1: Documento de ejemplo
// Ejemplo conceptual de un documento:
// { codigo: 1, nombre: "Libro X", autor: "Autor X", editoriales: ["A","B"] }


// PARTE 2: Crear base de datos y colección "libros"

use base1

// Insertar primer documento
db.libros.insertOne({
  _id: 1,
  nombre: "El aleph",
  autor: "Borges",
  editoriales: ["Planeta", "Siglo XXI"],
  precio: 20,
  cantidad: 50
})

// Insertar segundo documento
db.libros.insertOne({
  _id: 2,
  nombre: "Martin Fierro",
  autor: "Jose Hernandez",
  editoriales: ["Planeta"],
  precio: 50,
  cantidad: 12
})

// Ver la colección
db.libros.find()



// PARTE 3: Insertar múltiples documentos (insertMany)


use base1

db.libros.insertMany([
  {
    _id: 3,
    titulo: "Aprenda PHP",
    autor: "Mario Molina",
    editorial: ["Siglo XXI", "Planeta"],
    precio: 50,
    cantidad: 20
  },
  {
    _id: 4,
    titulo: "Java en 10 minutos",
    editorial: ["Siglo XXI"],
    precio: 45,
    cantidad: 1
  }
])

// Mostrar colección completa
db.libros.find()



// PARTE 4: Consultas con find()


// 4.1 Buscar documento con _id = 1
db.libros.find({ _id: 1 })

// 4.2 Libros con precio = 50
db.libros.find({ precio: 50 })

// 4.3 Libros con precio = 50 y cantidad = 20
db.libros.find({ precio: 50, cantidad: 20 })

// 4.4 Libros con precio mayor a 40
db.libros.find({ precio: { $gt: 40 } })

// 4.5 Libros con cantidad >= 50
db.libros.find({ cantidad: { $gte: 50 } })

// 4.6 Cantidad diferente de 50
db.libros.find({ cantidad: { $ne: 50 } })

// 4.7 Precio entre 20 y 45
db.libros.find({ precio: { $gte: 20, $lte: 45 } })

// 4.8 Libros editorial Planeta
db.libros.find({ editorial: { $in: ["Planeta"] } })

// 4.9 Libros que NO son de Planeta
db.libros.find({ editorial: { $nin: ["Planeta"] } })



// PARTE 5: Crear colección 'articulos'

use base1

// Borrar colección si existe
db.articulos.drop()

// Insertar documentos
db.articulos.insertMany([
  {
    _id: 1,
    nombre: "MULTIFUNCION HP DESKJET 2675",
    rubro: "impresora",
    precio: 3000,
    stock: 20
  },
  {
    _id: 2,
    nombre: "MULTIFUNCION EPSON EXPRESSION XP241",
    rubro: "impresora",
    precio: 3700,
    stock: 5
  },
  {
    _id: 3,
    nombre: "LED 19 PHILIPS",
    rubro: "monitor",
    precio: 4500,
    stock: 2
  },
  {
    _id: 4,
    nombre: "LED 22 PHILIPS",
    rubro: "monitor",
    precio: 5700,
    stock: 4
  }
])

// Ver colección
db.articulos.find()



// PARTE 6: Consultas sobre 'articulos'

// 6.1 Todos los artículos
db.articulos.find()

// 6.2 Artículos que NO son impresoras
db.articulos.find({ rubro: { $ne: "impresora" } })

// 6.3 Artículos del rubro mouse
db.articulos.find({ rubro: "mouse" })

// 6.4 Artículos con precio >= 5000
db.articulos.find({ precio: { $gte: 5000 } })




