function mostrarMensaje(seccion) {
    alert("Este es un mensaje desde " + seccion);
}
