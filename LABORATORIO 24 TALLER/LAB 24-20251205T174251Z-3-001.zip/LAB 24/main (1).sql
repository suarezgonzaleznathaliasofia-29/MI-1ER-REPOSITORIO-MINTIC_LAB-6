
# Parte 1: Creación de las Tablas


-- Crear tabla Autores
CREATE TABLE Autores (
    ID INT PRIMARY KEY,
    Nombre VARCHAR(50),
    Nacionalidad VARCHAR(50)
);

-- Crear tabla Libros
CREATE TABLE Libros (
    ID INT PRIMARY KEY,
    Titulo VARCHAR(100),
    Genero VARCHAR(50),
    Anio_Publicacion INT,
    Autor_ID INT,
    FOREIGN KEY (Autor_ID) REFERENCES Autores(ID)
);


# Parte 2: Inserción de Datos

-- Insertar registros en Autores
INSERT INTO Autores (ID, Nombre, Nacionalidad) VALUES
(1, 'Gabriel García Márquez', 'Colombiano'),
(2, 'J.K. Rowling', 'Británica'),
(3, 'George R. R. Martin', 'Estadounidense');

-- Insertar registros en Libros
INSERT INTO Libros (ID, Titulo, Genero, Anio_Publicacion, Autor_ID) VALUES
(1, 'Cien Anios de Soledad', 'Realismo Mágico', 1967, 1),
(2, 'El Amor en los Tiempos del Cólera', 'Realismo Mágico', 1985, 1),
(3, 'Harry Potter y la Piedra Filosofal', 'Fantasía', 1997, 2),
(4, 'Juego de Tronos', 'Fantasía', 1996, 3),
(5, 'Choque de Reyes', 'Fantasía', 1998, 3);


# Parte 3: Consultas SQL


# 3.1 Libros de un autor específico
SELECT Libros.Titulo, Autores.Nombre
FROM Libros
JOIN Autores ON Libros.Autor_ID = Autores.ID
WHERE Autores.Nombre = 'Gabriel García Márquez';


# 3.2 Libros publicados después del año 2000
SELECT Titulo, Anio_Publicacion
FROM Libros
WHERE Anio_Publicacion > 2000;


# 3.3 Autores con más de un libro publicado
SELECT Autores.Nombre, COUNT(Libros.ID) AS Cantidad_Libros
FROM Libros
JOIN Autores ON Libros.Autor_ID = Autores.ID
GROUP BY Autores.Nombre
HAVING Cantidad_Libros > 1;


# Parte 4: Actualización y Eliminación


# 4.1 Actualizar género de un libro
UPDATE Libros
SET Genero = 'Drama Histórico'
WHERE ID = 1;

# 4.2 Eliminar un autor y sus libros

DELETE FROM Libros WHERE Autor_ID = 3;

-- Luego se elimina el autor:

DELETE FROM Autores WHERE ID = 3;


# Parte 5: Mostrar Tabla Final


SELECT * FROM Libros;
SELECT * FROM Autores;

