
-- 1. CREACIÓN DE LA TABLA EMPLEADOS

CREATE TABLE empleados (
    id INT PRIMARY KEY,
    nombres VARCHAR(50),
    apellidos VARCHAR(50),
    puesto VARCHAR(50),
    salario DECIMAL(10,2),
    edad INT,
    celular VARCHAR(20),
    direccion VARCHAR(100)
);

-- 2. INSERCIÓN DE 10 REGISTROS

INSERT INTO empleados (id, nombres, apellidos, puesto, salario, edad, celular, direccion) VALUES
(1, 'Carlos', 'Perez', 'Gerente', 55000.00, 48, '3001234567', 'Calle 10 #20-30'),
(2, 'Maria', 'Gomez', 'Analista', 32000.00, 29, '3002345678', 'Carrera 5 #12-15'),
(3, 'Luis', 'Martinez', 'Programador', 40000.00, 25, '3003456789', 'Calle 15 #30-50'),
(4, 'Ana', 'Rodriguez', 'Diseñadora', 38000.00, 32, '3004567890', 'Carrera 7 #40-22'),
(5, 'Jorge', 'Ruiz', 'Programador', 47000.00, 27, '3005678901', 'Av Libertador #100'),
(6, 'Laura', 'Hernandez', 'Tester', 30000.00, 30, '3006789012', 'Calle 8 #33-22'),
(7, 'Pedro', 'Suarez', 'Soporte', 33000.00, 33, '3007890123', 'Calle 3 #44-19'),
(8, 'Sofia', 'Jimenez', 'Recursos Humanos', 41000.00, 31, '3008901234', 'Carrera 1 #21-14'),
(9, 'Ricardo', 'Lopez', 'Contador', 52000.00, 45, '3110902345', 'Av Central #55'),
(10,'Sara', 'Vargas', 'Marketing', 35000.00, 29, '3001230456', 'Calle 12 #9-19');


-- 3. CONSULTA DE TODOS LOS REGISTROS

SELECT * FROM empleados;


-- 4. CONSULTA: empleados con salario > 45000

SELECT nombres, apellidos, salario
FROM empleados
WHERE salario > 45000;


-- 5. CONSULTA: puestos de empleados mayores de 30 años

SELECT nombres, apellidos, puesto, edad
FROM empleados
WHERE edad > 30;


-- 6. ACTUALIZACIÓN: modificar salario de empleados 2 y 6

UPDATE empleados
SET salario = salario + 5000
WHERE id IN (2, 6);


-- 7. ACTUALIZACIÓN: modificar celular de empleados 7 y 8

UPDATE empleados
SET celular = '3009998888'
WHERE id = 7;

UPDATE empleados
SET celular = '3001112222'
WHERE id = 8;


-- 8. MOSTRAR TABLA COMPLETA TRAS LOS CAMBIOS


SELECT * FROM empleados;


-- 9. ELIMINAR EL REGISTRO CON ID = 3

DELETE FROM empleados
WHERE id = 3;


-- 10. MOSTRAR TABLA TRAS ELIMINACIÓN

SELECT * FROM empleados;

